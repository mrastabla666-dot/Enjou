package com.labib.honoredone.entity.goal;

/**
 * Tiny shared bit of state so Anmol/Noyon know when Super Sahil just
 * roasted Labib, so they can "argue back" a moment later instead of
 * talking over him at random.
 */
public final class BanterState {
    private static volatile long lastTauntTick = -1000;

    private BanterState() {}

    public static void recordTaunt(long worldTime) {
        lastTauntTick = worldTime;
    }

    public static boolean recentlyTaunted(long worldTime, long windowTicks) {
        return worldTime - lastTauntTick <= windowTicks;
    }
}
