package com.labib.honoredone.entity.goal;

import com.labib.honoredone.entity.LabibEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

public class SummonServantsGoal extends Goal {
    private final LabibEntity labib;

    public SummonServantsGoal(LabibEntity labib) {
        this.labib = labib;
        this.setControls(EnumSet.noneOf(Control.class));
    }

    @Override
    public boolean canStart() {
        return !this.labib.hasSummonedServants() && this.labib.getWorld() instanceof ServerWorld;
    }

    @Override
    public boolean shouldContinue() {
        return false;
    }

    @Override
    public void start() {
        if (!(this.labib.getWorld() instanceof ServerWorld world)) return;
        this.labib.markServantsSummoned();

        this.labib.summonServant(com.labib.honoredone.entity.ModEntities.ANMOL, world, 2.0);
        this.labib.summonServant(com.labib.honoredone.entity.ModEntities.NOYON, world, -2.0);

        PlayerEntity nearest = world.getClosestPlayer(this.labib, 32.0);
        if (nearest != null) {
            Vec3d p = this.labib.getPos();
            for (PlayerEntity player : world.getPlayers()) {
                if (player.squaredDistanceTo(p.x, p.y, p.z) < 64 * 64) {
                    player.sendMessage(Text.literal("Labib calls upon his servants, Anmol and Noyon!")
                            .formatted(Formatting.DARK_RED), false);
                }
            }
        }
    }
}
