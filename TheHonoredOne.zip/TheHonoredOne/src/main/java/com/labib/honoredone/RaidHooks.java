package com.labib.honoredone;

import com.labib.honoredone.entity.LabibEntity;
import com.labib.honoredone.entity.ModEntities;
import com.labib.honoredone.entity.SuperSahilEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.village.raid.Raid;
import net.minecraft.world.World;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class RaidHooks {
    private RaidHooks() {}

    // Prevents Labib from being summoned twice for the same raid (e.g. if the
    // final wave logic is re-evaluated, or on an extra "bonus" wave).
    private static final Set<Integer> HANDLED_RAIDS = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public static void onFinalWaveSpawned(Raid raid, int raidId, World world, BlockPos pos) {
        if (!(world instanceof ServerWorld serverWorld)) return;
        if (!HANDLED_RAIDS.add(raidId)) return;

        LabibEntity labib = ModEntities.LABIB.create(serverWorld);
        if (labib == null) return;
        labib.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5, 0.0f, 0.0f);
        labib.setPersistent();
        serverWorld.spawnEntity(labib);

        SuperSahilEntity sahil = ModEntities.SUPER_SAHIL.create(serverWorld);
        if (sahil != null) {
            sahil.refreshPositionAndAngles(pos.getX() - 1.5, pos.getY() + 1, pos.getZ() - 1.5, 0.0f, 0.0f);
            sahil.setPersistent();
            serverWorld.spawnEntity(sahil);
        }

        PlayerEntity nearest = serverWorld.getClosestPlayer(pos.getX(), pos.getY(), pos.getZ(), 64.0, false);
        for (PlayerEntity player : serverWorld.getPlayers()) {
            if (nearest == null || player.squaredDistanceTo(nearest) < 64 * 64) {
                player.sendMessage(Text.literal("The final wave brings forth Labib, The Honored One!")
                        .formatted(Formatting.DARK_RED, Formatting.BOLD), false);
                player.sendMessage(Text.literal("Super Sahil arrives to aid you in this fight!")
                        .formatted(Formatting.GOLD), false);
            }
        }
    }
}
