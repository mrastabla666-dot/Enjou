package com.labib.honoredone.entity.goal;

import com.labib.honoredone.entity.LabibEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.EnumSet;
import java.util.List;
import java.util.Random;

public class TauntLabibGoal extends Goal {
    private static final String[] LINES = {
            "Hey Labib, did you lose a fight to a wandering trader too?",
            "Labib's beard smells like llama spit, don't @ me.",
            "I've seen scarier things in a chicken jockey, Labib.",
            "Someone tell Labib the raid horn isn't a fashion accessory.",
            "Labib summons monsters because he can't win alone. Sad!",
            "Is that a crossbow, Labib, or did you just get cheaper?",
            "Anmol and Noyon, tell your boss Super Sahil says hi!",
            "Labib really said 'let's ruin this villager's day' and I said no."
    };

    private final MobEntity sahil;
    private final Random random = new Random();
    private int cooldown = 100;

    public TauntLabibGoal(MobEntity sahil) {
        this.sahil = sahil;
        this.setControls(EnumSet.noneOf(Control.class));
    }

    @Override
    public boolean canStart() {
        if (!(this.sahil.getWorld() instanceof ServerWorld world)) return false;
        return !world.getEntitiesByClass(LabibEntity.class, this.sahil.getBoundingBox().expand(32.0), e -> true).isEmpty();
    }

    @Override
    public boolean shouldContinue() {
        return true;
    }

    @Override
    public void tick() {
        if (this.cooldown-- > 0) return;
        this.cooldown = 140 + this.random.nextInt(160);
        if (!(this.sahil.getWorld() instanceof ServerWorld world)) return;

        String line = LINES[this.random.nextInt(LINES.length)];
        List<PlayerEntity> nearby = world.getEntitiesByClass(PlayerEntity.class,
                this.sahil.getBoundingBox().expand(32.0), PlayerEntity::isAlive);
        for (PlayerEntity player : nearby) {
            player.sendMessage(Text.literal("<Super Sahil> ").formatted(Formatting.GOLD)
                    .append(Text.literal(line).formatted(Formatting.WHITE)), false);
        }
        BanterState.recordTaunt(world.getTime());
    }
}
