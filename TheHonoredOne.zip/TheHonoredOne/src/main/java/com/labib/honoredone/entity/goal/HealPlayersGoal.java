package com.labib.honoredone.entity.goal;

import com.labib.honoredone.entity.LabibEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.EnumSet;
import java.util.List;

public class HealPlayersGoal extends Goal {
    private final MobEntity sahil;
    private int cooldown = 60;

    public HealPlayersGoal(MobEntity sahil) {
        this.sahil = sahil;
        this.setControls(EnumSet.of(Control.MOVE));
    }

    @Override
    public boolean canStart() {
        return this.sahil.getWorld() instanceof ServerWorld;
    }

    @Override
    public boolean shouldContinue() {
        return true;
    }

    @Override
    public void tick() {
        if (!(this.sahil.getWorld() instanceof ServerWorld world)) return;

        PlayerEntity nearest = world.getClosestPlayer(this.sahil, 40.0);
        if (nearest != null && this.sahil.squaredDistanceTo(nearest) > 25.0) {
            this.sahil.getNavigation().startMovingTo(nearest, 1.0);
        }

        if (this.cooldown-- > 0) return;

        List<PlayerEntity> nearby = world.getEntitiesByClass(PlayerEntity.class,
                this.sahil.getBoundingBox().expand(16.0), PlayerEntity::isAlive);

        boolean labibNearby = !world.getEntitiesByClass(LabibEntity.class,
                this.sahil.getBoundingBox().expand(24.0), e -> true).isEmpty();

        float healAmount = labibNearby ? 6.0f : 3.0f;
        this.cooldown = labibNearby ? 40 : 100;

        for (PlayerEntity player : nearby) {
            if (player.getHealth() < player.getMaxHealth()) {
                player.heal(healAmount);
                world.spawnParticles(ParticleTypes.HEART, player.getX(), player.getY() + 2.0, player.getZ(),
                        3, 0.3, 0.3, 0.3, 0.0);
                if (labibNearby) {
                    player.sendMessage(Text.literal("Super Sahil shields you from Labib's malice!")
                            .formatted(Formatting.GOLD), true);
                }
            }
        }
    }
}
