package com.labib.honoredone;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.labib.honoredone.entity.ModEntities;

public class TheHonoredOne implements ModInitializer {
    public static final String MOD_ID = "honoredone";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[The Honored One] Labib stirs in the shadow of the final wave...");
        ModEntities.register();
    }
}
