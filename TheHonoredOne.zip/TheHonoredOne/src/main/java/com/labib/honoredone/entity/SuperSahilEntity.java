package com.labib.honoredone.entity;

import com.labib.honoredone.entity.goal.HealPlayersGoal;
import com.labib.honoredone.entity.goal.TauntLabibGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.IronGolemEntity;
import net.minecraft.world.World;

public class SuperSahilEntity extends IronGolemEntity {

    public SuperSahilEntity(EntityType<? extends IronGolemEntity> entityType, World world) {
        super(entityType, world);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createSahilAttributes() {
        return IronGolemEntity.createIronGolemAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 120.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(2, new HealPlayersGoal(this));
        this.goalSelector.add(3, new TauntLabibGoal(this));
    }
}
