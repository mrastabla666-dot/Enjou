package com.labib.honoredone.entity.goal;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;

import java.util.EnumSet;

/**
 * A minimal melee-attack goal that deals damage directly instead of going
 * through the GENERIC_ATTACK_DAMAGE attribute. This lets Labib "enrage"
 * mobs that were never built with an attack-damage attribute (cows,
 * sheep, chickens, villagers, etc.) without the game crashing.
 */
public class EnragedAttackGoal extends Goal {
    private final MobEntity mob;
    private final double speed;
    private final float damage;
    private LivingEntity target;
    private int cooldown;

    public EnragedAttackGoal(MobEntity mob, double speed, float damage) {
        this.mob = mob;
        this.speed = speed;
        this.damage = damage;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        LivingEntity closest = this.mob.getWorld().getClosestPlayer(this.mob, 16.0);
        this.target = closest;
        return closest != null && closest.isAlive();
    }

    @Override
    public boolean shouldContinue() {
        return this.target != null && this.target.isAlive()
                && this.mob.squaredDistanceTo(this.target) < 400.0;
    }

    @Override
    public void stop() {
        this.target = null;
        this.mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (this.target == null) return;
        this.mob.getLookControl().lookAt(this.target, 30.0f, 30.0f);
        this.mob.getNavigation().startMovingTo(this.target, this.speed);

        double distSq = this.mob.squaredDistanceTo(this.target);
        if (this.cooldown > 0) this.cooldown--;

        double reach = this.mob.getWidth() * 2.0f * (this.mob.getWidth() * 2.0f) + this.target.getWidth();
        if (distSq <= Math.max(reach, 4.0) && this.cooldown <= 0) {
            this.cooldown = 20;
            this.mob.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            this.target.damage(this.mob.getDamageSources().mobAttack(this.mob), this.damage);
        }
    }
}
