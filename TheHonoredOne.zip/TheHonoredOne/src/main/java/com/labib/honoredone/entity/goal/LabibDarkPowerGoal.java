package com.labib.honoredone.entity.goal;

import com.labib.honoredone.mixin.MobEntityAccessor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.List;
import java.util.Random;

/**
 * Every so often Labib either:
 *  1) Curses nearby passive mobs, turning them into attackers, or
 *  2) Rips open a portal and drops a random hostile mob on the player.
 *
 * Excludes: wither, warden, ender dragon, shulker, elder guardian.
 */
public class LabibDarkPowerGoal extends Goal {

    private static final EntityType<?>[] SUMMON_POOL = new EntityType<?>[] {
            EntityType.ZOMBIE, EntityType.HUSK, EntityType.DROWNED, EntityType.SKELETON,
            EntityType.STRAY, EntityType.SPIDER, EntityType.CAVE_SPIDER, EntityType.CREEPER,
            EntityType.WITCH, EntityType.ENDERMAN, EntityType.VINDICATOR, EntityType.EVOKER,
            EntityType.PILLAGER, EntityType.VEX, EntityType.RAVAGER, EntityType.SILVERFISH,
            EntityType.PHANTOM, EntityType.GUARDIAN, EntityType.SLIME, EntityType.MAGMA_CUBE,
            EntityType.HOGLIN, EntityType.ZOGLIN, EntityType.PIGLIN, EntityType.PIGLIN_BRUTE,
            EntityType.BLAZE, EntityType.GHAST
    };

    private final MobEntity labib;
    private final Random random = new Random();
    private int cooldown = 100;

    public LabibDarkPowerGoal(MobEntity labib) {
        this.labib = labib;
        this.setControls(EnumSet.noneOf(Control.class));
    }

    @Override
    public boolean canStart() {
        return this.labib.getWorld() instanceof ServerWorld && this.labib.getTarget() != null;
    }

    @Override
    public boolean shouldContinue() {
        return this.canStart();
    }

    @Override
    public void tick() {
        if (this.cooldown-- > 0) return;
        this.cooldown = 200 + this.random.nextInt(200); // ~10-20s

        if (!(this.labib.getWorld() instanceof ServerWorld world)) return;
        PlayerEntity target = world.getClosestPlayer(this.labib, 32.0);
        if (target == null) return;

        if (this.random.nextBoolean()) {
            this.summonHostileMob(world, target);
        } else {
            this.enrageNearbyPassiveMobs(world, target);
        }
    }

    private void summonHostileMob(ServerWorld world, PlayerEntity target) {
        EntityType<?> type = SUMMON_POOL[this.random.nextInt(SUMMON_POOL.length)];
        Vec3d pos = target.getPos().add((this.random.nextDouble() - 0.5) * 8, 1, (this.random.nextDouble() - 0.5) * 8);
        Entity summoned = type.create(world);
        if (summoned == null) return;
        summoned.refreshPositionAndAngles(pos.x, pos.y, pos.z, this.labib.getYaw(), 0.0f);
        world.spawnEntity(summoned);
        if (summoned instanceof MobEntity mobEntity) {
            mobEntity.setTarget(target);
            mobEntity.setPersistent();
        }
        broadcastNear(world, target, Text.literal("Labib tears open the shadows and summons a ")
                .append(Text.literal(type.getName().getString()).formatted(Formatting.DARK_RED))
                .append("!").formatted(Formatting.GRAY));
    }

    private void enrageNearbyPassiveMobs(ServerWorld world, PlayerEntity target) {
        Box box = this.labib.getBoundingBox().expand(14.0);
        List<AnimalEntity> passives = world.getEntitiesByClass(AnimalEntity.class, box, e -> !e.getCommandTags().contains("honoredone_enraged"));
        int converted = 0;
        for (AnimalEntity animal : passives) {
            if (converted >= 4) break;
            if (!(animal instanceof PathAwareEntity)) continue;
            animal.addCommandTag("honoredone_enraged");
            MobEntityAccessor accessor = (MobEntityAccessor) animal;
            accessor.honoredone$getGoalSelector().add(0, new EnragedAttackGoal(animal, 1.3, 3.0f));
            accessor.honoredone$getTargetSelector().add(0, new ActiveTargetGoal<>(animal, PlayerEntity.class, true));
            animal.setTarget(target);
            converted++;
        }
        if (converted > 0) {
            broadcastNear(world, target, Text.literal("Labib's dark whisper turns the animals against you!")
                    .formatted(Formatting.DARK_PURPLE));
        }
    }

    private static void broadcastNear(World world, PlayerEntity center, Text text) {
        for (PlayerEntity p : world.getPlayers()) {
            if (p.squaredDistanceTo(center) < 64 * 64) {
                p.sendMessage(text, false);
            }
        }
    }
}
