package com.labib.honoredone.entity;

import com.labib.honoredone.entity.goal.DefendLabibGoal;
import com.labib.honoredone.entity.goal.FollowLeaderGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.world.World;

public class AnmolEntity extends PillagerEntity {

    private LabibEntity leader;

    public AnmolEntity(EntityType<? extends PillagerEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createAnmolAttributes() {
        return PillagerEntity.createPillagerAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 26.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0);
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(2, new FollowLeaderGoal(this, () -> (LivingEntity) this.leader, 1.15));
        this.goalSelector.add(3, new DefendLabibGoal(this, "Anmol"));
    }

    public void setLeader(LabibEntity leader) {
        this.leader = leader;
    }
}
