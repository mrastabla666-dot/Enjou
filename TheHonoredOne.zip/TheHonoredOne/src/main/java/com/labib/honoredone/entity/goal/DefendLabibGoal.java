package com.labib.honoredone.entity.goal;

import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.EnumSet;
import java.util.List;
import java.util.Random;

public class DefendLabibGoal extends Goal {
    private static final String[] LINES = {
            "Don't you DARE talk about Labib like that, Sahil!",
            "Labib is the strongest raid captain there ever was, take it back!",
            "You wouldn't last two seconds against Labib, Sahil!",
            "We didn't ask, Super Sahil. Nobody asked.",
            "Labib has more style in one pillager arm than you have in your whole golem body!",
            "Keep talking, Sahil, Labib's summons are already on their way.",
            "Anmol says: Sahil is just jealous he doesn't have servants like us!",
            "Noyon says: At least Labib doesn't heal people for attention."
    };

    private final MobEntity speaker;
    private final String name;
    private final Random random = new Random();
    private int cooldown = 60;

    public DefendLabibGoal(MobEntity speaker, String name) {
        this.speaker = speaker;
        this.name = name;
        this.setControls(EnumSet.noneOf(Control.class));
    }

    @Override
    public boolean canStart() {
        return this.speaker.getWorld() instanceof ServerWorld;
    }

    @Override
    public boolean shouldContinue() {
        return true;
    }

    @Override
    public void tick() {
        if (this.cooldown-- > 0) return;
        if (!(this.speaker.getWorld() instanceof ServerWorld world)) return;

        boolean triggered = BanterState.recentlyTaunted(world.getTime(), 100);
        // React quickly after a taunt, otherwise chime in occasionally anyway.
        if (!triggered && this.random.nextInt(6) != 0) {
            this.cooldown = 40;
            return;
        }
        this.cooldown = triggered ? 200 : 300 + this.random.nextInt(200);

        String line = LINES[this.random.nextInt(LINES.length)];
        List<PlayerEntity> nearby = world.getEntitiesByClass(PlayerEntity.class,
                this.speaker.getBoundingBox().expand(32.0), PlayerEntity::isAlive);
        for (PlayerEntity player : nearby) {
            player.sendMessage(Text.literal("<" + this.name + "> ").formatted(Formatting.DARK_RED)
                    .append(Text.literal(line).formatted(Formatting.GRAY)), false);
        }
    }
}
