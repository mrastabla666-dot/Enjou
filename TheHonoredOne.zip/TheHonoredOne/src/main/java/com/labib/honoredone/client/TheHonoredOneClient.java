package com.labib.honoredone.client;

import com.labib.honoredone.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.IronGolemEntityRenderer;
import net.minecraft.client.render.entity.PillagerEntityRenderer;

public class TheHonoredOneClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Reuses vanilla Pillager / Iron Golem models + textures so the mod
        // works out of the box with zero extra art assets. Swap these out
        // for custom EntityRenderer implementations later if you add
        // dedicated textures under assets/honoredone/textures/entity/.
        EntityRendererRegistry.register(ModEntities.LABIB, PillagerEntityRenderer::new);
        EntityRendererRegistry.register(ModEntities.ANMOL, PillagerEntityRenderer::new);
        EntityRendererRegistry.register(ModEntities.NOYON, PillagerEntityRenderer::new);
        EntityRendererRegistry.register(ModEntities.SUPER_SAHIL, IronGolemEntityRenderer::new);
    }
}
