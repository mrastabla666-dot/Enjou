package com.labib.honoredone.entity.goal;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;

import java.util.EnumSet;
import java.util.function.Supplier;

public class FollowLeaderGoal extends Goal {
    private final MobEntity self;
    private final Supplier<LivingEntity> leaderSupplier;
    private final double speed;

    public FollowLeaderGoal(MobEntity self, Supplier<LivingEntity> leaderSupplier, double speed) {
        this.self = self;
        this.leaderSupplier = leaderSupplier;
        this.speed = speed;
        this.setControls(EnumSet.of(Control.MOVE));
    }

    @Override
    public boolean canStart() {
        LivingEntity leader = this.leaderSupplier.get();
        return leader != null && leader.isAlive() && this.self.squaredDistanceTo(leader) > 36.0
                && this.self.getTarget() == null;
    }

    @Override
    public boolean shouldContinue() {
        LivingEntity leader = this.leaderSupplier.get();
        return leader != null && leader.isAlive() && this.self.squaredDistanceTo(leader) > 9.0
                && this.self.getTarget() == null;
    }

    @Override
    public void tick() {
        LivingEntity leader = this.leaderSupplier.get();
        if (leader != null) {
            this.self.getNavigation().startMovingTo(leader, this.speed);
        }
    }
}
