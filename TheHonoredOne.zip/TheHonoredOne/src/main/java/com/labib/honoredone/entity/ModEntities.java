package com.labib.honoredone.entity;

import com.labib.honoredone.TheHonoredOne;
import net.fabricmc.fabric.api.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    private ModEntities() {}

    public static final EntityType<LabibEntity> LABIB = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(TheHonoredOne.MOD_ID, "labib"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, LabibEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
                    .trackRangeBlocks(64)
                    .build()
    );

    public static final EntityType<AnmolEntity> ANMOL = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(TheHonoredOne.MOD_ID, "anmol"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, AnmolEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
                    .trackRangeBlocks(64)
                    .build()
    );

    public static final EntityType<NoyonEntity> NOYON = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(TheHonoredOne.MOD_ID, "noyon"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, NoyonEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
                    .trackRangeBlocks(64)
                    .build()
    );

    public static final EntityType<SuperSahilEntity> SUPER_SAHIL = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(TheHonoredOne.MOD_ID, "super_sahil"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, SuperSahilEntity::new)
                    .dimensions(EntityDimensions.fixed(1.4f, 2.7f))
                    .trackRangeBlocks(64)
                    .build()
    );

    public static void register() {
        FabricDefaultAttributeRegistry.register(LABIB, LabibEntity.createLabibAttributes());
        FabricDefaultAttributeRegistry.register(ANMOL, AnmolEntity.createAnmolAttributes());
        FabricDefaultAttributeRegistry.register(NOYON, NoyonEntity.createNoyonAttributes());
        FabricDefaultAttributeRegistry.register(SUPER_SAHIL, SuperSahilEntity.createSahilAttributes());
    }
}
