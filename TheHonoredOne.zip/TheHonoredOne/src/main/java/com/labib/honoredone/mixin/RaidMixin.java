package com.labib.honoredone.mixin;

import com.labib.honoredone.RaidHooks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.village.raid.Raid;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Raid.class)
public abstract class RaidMixin {

    @Shadow public abstract int getGroupsSpawned();

    @Shadow public abstract int getMaxWaves(Difficulty difficulty);

    @Shadow public abstract World getWorld();

    @Shadow public abstract int getRaidId();

    @Inject(method = "spawnNextWave", at = @At("TAIL"))
    private void honoredone$onSpawnNextWave(BlockPos pos, CallbackInfo ci) {
        Raid self = (Raid) (Object) this;
        World world = this.getWorld();
        int groupsSpawned = this.getGroupsSpawned();
        int maxWaves = this.getMaxWaves(world.getDifficulty());

        if (groupsSpawned >= maxWaves) {
            RaidHooks.onFinalWaveSpawned(self, this.getRaidId(), world, pos);
        }
    }
}
