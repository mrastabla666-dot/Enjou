package com.labib.honoredone.entity;

import com.labib.honoredone.entity.goal.LabibDarkPowerGoal;
import com.labib.honoredone.entity.goal.SummonServantsGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

public class LabibEntity extends PillagerEntity {

    private boolean summonedServants = false;

    public LabibEntity(EntityType<? extends PillagerEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createLabibAttributes() {
        return PillagerEntity.createPillagerAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.35)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(0, new SummonServantsGoal(this));
        this.goalSelector.add(1, new LabibDarkPowerGoal(this));
    }

    public boolean hasSummonedServants() {
        return this.summonedServants;
    }

    public void markServantsSummoned() {
        this.summonedServants = true;
    }

    public void summonServant(EntityType<? extends MobEntity> type, ServerWorld world, double xOffset) {
        MobEntity servant = type.create(world);
        if (servant == null) return;
        servant.refreshPositionAndAngles(this.getX() + xOffset, this.getY(), this.getZ(), this.getYaw(), 0.0f);
        servant.setPersistent();
        if (servant instanceof AnmolEntity anmol) anmol.setLeader(this);
        if (servant instanceof NoyonEntity noyon) noyon.setLeader(this);
        world.spawnEntity(servant);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("SummonedServants", this.summonedServants);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.summonedServants = nbt.getBoolean("SummonedServants");
    }
}
