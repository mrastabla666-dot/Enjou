package com.enjou.item;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.Util;

/** A block item (seeds/grapes) that keeps its own item name instead of the block's. */
public class NamedBlockItem extends BlockItem {
    public NamedBlockItem(Block block, Settings settings) {
        super(block, settings);
    }

    @Override
    public String getTranslationKey() {
        return Util.createTranslationKey("item", Registries.ITEM.getId(this));
    }
}
