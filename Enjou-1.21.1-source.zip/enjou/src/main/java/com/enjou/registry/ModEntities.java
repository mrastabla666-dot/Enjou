package com.enjou.registry;

import com.enjou.Enjou;
import com.enjou.entity.AnmolEntity;
import com.enjou.entity.RaihanEntity;
import com.enjou.entity.SahilEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public class ModEntities {
    public static final EntityType<RaihanEntity> RAIHAN = Registry.register(Registries.ENTITY_TYPE, Enjou.id("raihan"),
        FabricEntityTypeBuilder.<RaihanEntity>createMob()
            .spawnGroup(SpawnGroup.CREATURE)
            .entityFactory(RaihanEntity::new)
            .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
            .spawnRestriction(SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn)
            .defaultAttributes(RaihanEntity::createAttributes)
            .build());

    public static final EntityType<SahilEntity> SAHIL = Registry.register(Registries.ENTITY_TYPE, Enjou.id("sahil"),
        FabricEntityTypeBuilder.<SahilEntity>createMob()
            .spawnGroup(SpawnGroup.CREATURE)
            .entityFactory(SahilEntity::new)
            .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
            .spawnRestriction(SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn)
            .defaultAttributes(SahilEntity::createAttributes)
            .build());

    public static final EntityType<AnmolEntity> ANMOL = Registry.register(Registries.ENTITY_TYPE, Enjou.id("anmol"),
        FabricEntityTypeBuilder.<AnmolEntity>createMob()
            .spawnGroup(SpawnGroup.CREATURE)
            .entityFactory(AnmolEntity::new)
            .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
            .spawnRestriction(SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn)
            .defaultAttributes(AnmolEntity::createAttributes)
            .build());

    public static void init() {
        // Natural spawns (rare). Spawn eggs are in the Enjou creative tab.
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, RAIHAN, 2, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, SAHIL, 2, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, ANMOL, 1, 1, 1);
    }
}
