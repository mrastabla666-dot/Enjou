package com.enjou.registry;

import com.enjou.Enjou;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public class ModItemGroups {
    public static final ItemGroup MAIN = Registry.register(Registries.ITEM_GROUP, Enjou.id("main"),
        FabricItemGroup.builder()
            .icon(() -> new ItemStack(ModItems.DESHI_WINE))
            .displayName(Text.translatable("itemGroup.enjou.main"))
            .entries((context, entries) -> {
                entries.add(ModItems.RAIHAN_SPAWN_EGG);
                entries.add(ModItems.SAHIL_SPAWN_EGG);
                entries.add(ModItems.ANMOL_SPAWN_EGG);
                entries.add(ModItems.GRAPES);
                entries.add(ModItems.DESHI_WINE);
                entries.add(ModItems.TOBACCO_SEEDS);
                entries.add(ModItems.TOBACCO_LEAF);
                entries.add(ModItems.DRIED_TOBACCO_LEAF);
                entries.add(ModItems.CIGARETTE);
                entries.add(ModItems.CAT_ARMOR_PLATING);
                entries.add(ModItems.CAT_ARMOR);
            })
            .build());

    public static void init() {}
}
