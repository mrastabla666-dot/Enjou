package com.enjou.registry;

import com.enjou.Enjou;
import com.enjou.item.CigaretteItem;
import com.enjou.item.NamedBlockItem;
import com.enjou.item.WineItem;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModItems {
    public static final Item GRAPES = register("grapes", new NamedBlockItem(ModBlocks.GRAPE_VINE,
        new Item.Settings().food(new FoodComponent.Builder().nutrition(2).saturationModifier(0.3f).build())));
    public static final Item TOBACCO_SEEDS = register("tobacco_seeds",
        new NamedBlockItem(ModBlocks.TOBACCO_CROP, new Item.Settings()));
    public static final Item TOBACCO_LEAF = register("tobacco_leaf", new Item(new Item.Settings()));
    public static final Item DRIED_TOBACCO_LEAF = register("dried_tobacco_leaf", new Item(new Item.Settings()));
    public static final Item CIGARETTE = register("cigarette", new CigaretteItem(new Item.Settings()));
    public static final Item DESHI_WINE = register("deshi_wine", new WineItem(new Item.Settings().maxCount(16)));

    /** Only obtainable by trading with Anmol. */
    public static final Item CAT_ARMOR_PLATING = register("cat_armor_plating", new Item(new Item.Settings()));

    public static final Item CAT_ARMOR = register("cat_armor", new Item(new Item.Settings()
        .maxCount(1)
        .component(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.builder()
            .add(EntityAttributes.GENERIC_ARMOR,
                new EntityAttributeModifier(Enjou.id("cat_armor"), 8.0, EntityAttributeModifier.Operation.ADD_VALUE),
                AttributeModifierSlot.BODY)
            .build())));

    public static final Item RAIHAN_SPAWN_EGG = register("raihan_spawn_egg",
        new SpawnEggItem(ModEntities.RAIHAN, 0x7A1E1E, 0xE0B070, new Item.Settings()));
    public static final Item SAHIL_SPAWN_EGG = register("sahil_spawn_egg",
        new SpawnEggItem(ModEntities.SAHIL, 0x3E7D3A, 0xF2F2F2, new Item.Settings()));
    public static final Item ANMOL_SPAWN_EGG = register("anmol_spawn_egg",
        new SpawnEggItem(ModEntities.ANMOL, 0x5A328C, 0xF0A030, new Item.Settings()));

    private static <T extends Item> T register(String name, T item) {
        return Registry.register(Registries.ITEM, Enjou.id(name), item);
    }

    public static void init() {}
}
