package com.enjou.entity;

import com.enjou.registry.ModItems;
import com.enjou.util.ChatUtil;
import com.enjou.util.Lines;
import java.util.Optional;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtCustomerGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.StopFollowingCustomerGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.random.Random;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOfferList;
import net.minecraft.village.TradedItem;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Anmol: cat lover and shopkeeper. Sells cat spawn eggs and the only source of Cat Armor Plating. */
public class AnmolEntity extends MerchantEntity {
    public AnmolEntity(EntityType<? extends AnmolEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return EnjouAttributes.trader();
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new StopFollowingCustomerGoal(this));
        goalSelector.add(2, new LookAtCustomerGoal(this));
        goalSelector.add(4, new WanderAroundFarGoal(this, 0.35));
        goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(6, new LookAroundGoal(this));
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty difficulty) {
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.COD));
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (isAlive() && !hasCustomer() && !isBaby()) {
            if (hand == Hand.MAIN_HAND) {
                player.incrementStat(Stats.TALKED_TO_VILLAGER);
            }
            if (!getWorld().isClient) {
                setCustomer(player);
                sendOffers(player, getDisplayName(), 1);
                ChatUtil.say(this, ChatUtil.pick(Lines.ANMOL_GREETING, random), 8);
            }
            return ActionResult.success(getWorld().isClient);
        }
        return super.interactMob(player, hand);
    }

    /** Affordable prices, as promised. */
    protected void fillRecipes() {
        TradeOfferList offers = getOffers();
        // Cat spawn eggs for gold, diamonds or netherite
        offers.add(new TradeOffer(new TradedItem(Items.GOLD_INGOT, 8), new ItemStack(Items.CAT_SPAWN_EGG), 8, 5, 0.05f));
        offers.add(new TradeOffer(new TradedItem(Items.DIAMOND, 2), new ItemStack(Items.CAT_SPAWN_EGG), 8, 8, 0.05f));
        offers.add(new TradeOffer(new TradedItem(Items.NETHERITE_SCRAP, 1), new ItemStack(Items.CAT_SPAWN_EGG, 2), 4, 12, 0.05f));
        // The crafting material for Cat Armor (only sold here)
        offers.add(new TradeOffer(new TradedItem(Items.DIAMOND, 1), Optional.of(new TradedItem(Items.GOLD_INGOT, 3)),
            new ItemStack(ModItems.CAT_ARMOR_PLATING, 2), 8, 10, 0.05f));
        offers.add(new TradeOffer(new TradedItem(Items.NETHERITE_SCRAP, 1),
            new ItemStack(ModItems.CAT_ARMOR_PLATING, 4), 4, 15, 0.05f));
    }

    protected void afterUsing(TradeOffer offer) {
        if (offer.shouldRewardPlayerExperience()) {
            int xp = 3 + random.nextInt(4);
            getWorld().spawnEntity(new ExperienceOrbEntity(getWorld(), getX(), getY() + 0.5, getZ(), xp));
        }
    }

    // The next four have no @Override on purpose so they compile whether MerchantEntity defines them or not.
    public int getExperience() {
        return 0;
    }

    public void setExperienceFromServer(int experience) {}

    public boolean isLeveledMerchant() {
        return false;
    }

    public SoundEvent getYesSound() {
        return SoundEvents.ENTITY_VILLAGER_YES;
    }

    @Nullable
    public PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return hasCustomer() ? SoundEvents.ENTITY_VILLAGER_TRADE : SoundEvents.ENTITY_VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_VILLAGER_DEATH;
    }
}
