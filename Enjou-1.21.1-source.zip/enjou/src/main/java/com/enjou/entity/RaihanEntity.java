package com.enjou.entity;

import com.enjou.registry.ModItems;
import com.enjou.util.ChatUtil;
import com.enjou.util.Lines;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;

/** Raihan: always drunk, always smoking, loves to chat. Hates Sahil. */
public class RaihanEntity extends EnjouMobEntity {
    private int talkCooldown = 40;

    public RaihanEntity(EntityType<? extends RaihanEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return EnjouAttributes.fighter();
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new MeleeAttackGoal(this, 1.1, true));
        goalSelector.add(2, new WanderAroundFarGoal(this, 0.6));
        goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));
        goalSelector.add(4, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, SahilEntity.class, true));
    }

    @Override
    protected String[] fightLines() {
        return Lines.RAIHAN_FIGHT;
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty difficulty) {
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(ModItems.DESHI_WINE));
        equipStack(EquipmentSlot.OFFHAND, new ItemStack(ModItems.CIGARETTE));
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
        setEquipmentDropChance(EquipmentSlot.OFFHAND, 0.0f);
    }

    @Override
    public void tickMovement() {
        super.tickMovement();
        if (getWorld() instanceof ServerWorld serverWorld) {
            // Cigarette smoke
            if (age % 8 == 0) {
                Vec3d look = getRotationVec(1.0f);
                serverWorld.spawnParticles(ParticleTypes.SMOKE,
                    getX() + look.x * 0.4, getEyeY() - 0.1, getZ() + look.z * 0.4,
                    1, 0.05, 0.05, 0.05, 0.005);
            }
            // Drunk stagger
            if (isOnGround() && getTarget() == null && random.nextInt(12) == 0) {
                addVelocity((random.nextDouble() - 0.5) * 0.25, 0.0, (random.nextDouble() - 0.5) * 0.25);
                velocityModified = true;
            }
            // Mumble drunkenly at nearby players
            if (talkCooldown > 0) {
                talkCooldown--;
            } else if (age % 10 == 0 && getTarget() == null) {
                PlayerEntity player = getWorld().getClosestPlayer(this, 5.0);
                if (player != null && !player.isSpectator()) {
                    ChatUtil.say(this, ChatUtil.pick(Lines.RAIHAN_DRUNK, random), 24);
                    talkCooldown = 100 + random.nextInt(100);
                }
            }
        }
    }
}
