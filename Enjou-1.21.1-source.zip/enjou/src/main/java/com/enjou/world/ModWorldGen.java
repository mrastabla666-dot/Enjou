package com.enjou.world;

import com.enjou.Enjou;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

public class ModWorldGen {
    public static final RegistryKey<PlacedFeature> WILD_GRAPE_PATCH =
        RegistryKey.of(RegistryKeys.PLACED_FEATURE, Enjou.id("wild_grape_patch"));
    public static final RegistryKey<PlacedFeature> WILD_TOBACCO_PATCH =
        RegistryKey.of(RegistryKeys.PLACED_FEATURE, Enjou.id("wild_tobacco_patch"));

    public static void init() {
        // Wild grapes in all jungle biomes
        BiomeModifications.addFeature(
            BiomeSelectors.includeByKey(BiomeKeys.JUNGLE, BiomeKeys.SPARSE_JUNGLE, BiomeKeys.BAMBOO_JUNGLE),
            GenerationStep.Feature.VEGETAL_DECORATION, WILD_GRAPE_PATCH);
        // Wild tobacco in warm open biomes, so you can find tobacco seeds
        BiomeModifications.addFeature(
            BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.SUNFLOWER_PLAINS, BiomeKeys.SAVANNA, BiomeKeys.MEADOW),
            GenerationStep.Feature.VEGETAL_DECORATION, WILD_TOBACCO_PATCH);
    }
}
