package com.enjou.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;

/**
 * Crop with 4 growth stages (0-3) that can be planted on farmland (normal crop)
 * and also survives on dirt/grass so wild patches can generate in the world.
 */
public abstract class EnjouCropBlock extends CropBlock {
    public static final IntProperty AGE = Properties.AGE_3;

    protected EnjouCropBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected IntProperty getAgeProperty() {
        return AGE;
    }

    @Override
    public int getMaxAge() {
        return 3;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    @Override
    protected boolean canPlantOnTop(BlockState floor, BlockView world, BlockPos pos) {
        return floor.isOf(Blocks.FARMLAND) || floor.isIn(BlockTags.DIRT);
    }

    /** Skips the vanilla light check so wild patches can be placed during world generation. */
    @Override
    protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        BlockPos below = pos.down();
        return canPlantOnTop(world.getBlockState(below), world, below);
    }
}
