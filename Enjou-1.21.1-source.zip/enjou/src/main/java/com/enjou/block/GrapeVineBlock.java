package com.enjou.block;

import com.enjou.registry.ModItems;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.CropBlock;
import net.minecraft.item.ItemConvertible;

public class GrapeVineBlock extends EnjouCropBlock {
    public static final MapCodec<GrapeVineBlock> CODEC = createCodec(GrapeVineBlock::new);

    public GrapeVineBlock(Settings settings) {
        super(settings);
    }

    @Override
    public MapCodec<? extends CropBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected ItemConvertible getSeedsItem() {
        return ModItems.GRAPES;
    }
}
