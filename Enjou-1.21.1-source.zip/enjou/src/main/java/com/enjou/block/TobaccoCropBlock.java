package com.enjou.block;

import com.enjou.registry.ModItems;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.CropBlock;
import net.minecraft.item.ItemConvertible;

public class TobaccoCropBlock extends EnjouCropBlock {
    public static final MapCodec<TobaccoCropBlock> CODEC = createCodec(TobaccoCropBlock::new);

    public TobaccoCropBlock(Settings settings) {
        super(settings);
    }

    @Override
    public MapCodec<? extends CropBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected ItemConvertible getSeedsItem() {
        return ModItems.TOBACCO_SEEDS;
    }
}
