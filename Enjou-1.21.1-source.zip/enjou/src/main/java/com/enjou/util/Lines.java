package com.enjou.util;

/** All the things the Enjou characters say. Edit freely. */
public final class Lines {
    private Lines() {}

    public static final String[] RAIHAN_DRUNK = {
        "Hic... bhai, tu kaun hai? Tu bhi pee le!",
        "Aaj raat... hic... party hai, bro!",
        "Oye, ek aur peg dena yaar...",
        "Duniya ghoom rahi hai kya? Ya main?",
        "Main nashe mein nahi hu... *hic*",
        "Tu mera best friend hai, janta hai na?",
        "Cigarette hai kya bhai? ...Nahi? Fir bhi tu legend hai!",
        "Hic! Deshi wine is the best, bro!",
        "Mujhe ghar jaana hai... lekin ghar kahan hai?",
        "Arre wah! Tu to double dikh raha hai!"
    };

    public static final String[] RAIHAN_FIGHT = {
        "Oye Sahil, tu gaay se bhi zyada bewakoof hai!",
        "Aa, dekhta hu tujhe, gaay-wale!",
        "Hic... Sahil, tera dimaag kharab hai!",
        "Chal hat, pagle!",
        "Tu kya samajhta hai khud ko, ha?!",
        "Tere se na ho payega, chhote!",
        "Hic! Pakad ke dikha, bandar!"
    };

    public static final String[] SAHIL_FIGHT = {
        "Raihan, tu nashe mein bhi gadha hai!",
        "Meri gaayon se door reh, sharabi!",
        "Aaja nashedi, aaj teri baari hai!",
        "Tujhse pehle meri gaay jeet jayegi, bewakoof!",
        "Dhat! Nikal yahan se, bakwaas!",
        "Tu to bilkul ullu hai, Raihan!",
        "Moo-ve! Hat saamne se!"
    };

    public static final String[] SAHIL_SCARE = {
        "BOO! Hehehe!",
        "Dar gaya na? Hahaha!",
        "Bhaag chhote, bhaag!",
        "Hehe, got you!"
    };

    public static final String[] ANMOL_GREETING = {
        "Meow! Cat lover? You've come to the right shop!",
        "Welcome, welcome! Cats, eggs and armour, all affordable!",
        "Purrfect timing, friend. Take a look!"
    };
}
