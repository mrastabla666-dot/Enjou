package com.enjou.util;

import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public final class ChatUtil {
    private ChatUtil() {}

    /** Sends "<Name> line" to every player within {@code range} blocks of the speaker. */
    public static void say(MobEntity speaker, String line, double range) {
        World world = speaker.getWorld();
        if (world.isClient) {
            return;
        }
        MutableText msg = Text.literal("<")
            .append(speaker.getName().copy().formatted(Formatting.GOLD))
            .append(Text.literal("> " + line));
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, speaker.getBoundingBox().expand(range), p -> true)) {
            player.sendMessage(msg, false);
        }
    }

    public static String pick(String[] lines, Random random) {
        return lines[random.nextInt(lines.length)];
    }
}
