package com.enjou.client;

import com.enjou.Enjou;
import com.enjou.registry.ModItems;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.CatEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.util.Identifier;

/** Draws the Cat Armor plating over a cat's body. */
public class CatArmorFeatureRenderer extends FeatureRenderer<CatEntity, CatEntityModel<CatEntity>> {
    private static final Identifier TEXTURE = Enjou.id("textures/entity/cat_armor.png");

    public CatArmorFeatureRenderer(FeatureRendererContext<CatEntity, CatEntityModel<CatEntity>> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CatEntity cat,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress,
                       float headYaw, float headPitch) {
        if (!cat.getEquippedStack(EquipmentSlot.BODY).isOf(ModItems.CAT_ARMOR)) {
            return;
        }
        matrices.push();
        matrices.scale(1.04f, 1.04f, 1.04f);
        renderModel(getContextModel(), TEXTURE, matrices, vertexConsumers, light, cat, -1);
        matrices.pop();
    }
}
