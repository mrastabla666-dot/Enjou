package com.enjou.client;

import com.enjou.Enjou;
import com.enjou.entity.AnmolEntity;
import com.enjou.entity.RaihanEntity;
import com.enjou.entity.SahilEntity;
import com.enjou.registry.ModBlocks;
import com.enjou.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.CatEntityRenderer;
import net.minecraft.entity.EntityType;

public class EnjouClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.RAIHAN,
            ctx -> new HumanoidMobRenderer<RaihanEntity>(ctx, Enjou.id("textures/entity/raihan.png")));
        EntityRendererRegistry.register(ModEntities.SAHIL,
            ctx -> new HumanoidMobRenderer<SahilEntity>(ctx, Enjou.id("textures/entity/sahil.png")));
        EntityRendererRegistry.register(ModEntities.ANMOL,
            ctx -> new HumanoidMobRenderer<AnmolEntity>(ctx, Enjou.id("textures/entity/anmol.png")));

        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(), ModBlocks.GRAPE_VINE, ModBlocks.TOBACCO_CROP);

        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
            if (type == EntityType.CAT && renderer instanceof CatEntityRenderer catRenderer) {
                helper.register(new CatArmorFeatureRenderer(catRenderer));
            }
        });
    }
}
